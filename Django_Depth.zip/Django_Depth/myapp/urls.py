from django.urls import path
from . import views

# user name-Ravi
# pwd-Ravi@123.

urlpatterns = [
    path('Flex/', views.Flex, name='Flex'),
    path('', views.navbar, name='navbar'),
    path('about/', views.about, name='about'),
    path('contact/', views.contact, name='contact'),
    path('signup/', views.signup, name='signup'),
    path('login/', views.login, name='login'),
    path('search/', views.search_player, name='search_player'),
    path('about/', views.about, name='about'),
    path('contact/', views.contact, name='contact'),
    path('contact_view', views.contact_view, name='contact_view'),
    path('success/', views.contact_view, name='success'),
    path('teams/', views.teams, name='teams'),
    path('invalid/', views.invalid, name='invalid'),
    path('Notfound/', views.Notfound, name='Notfound'),
    path('info/', views.info, name='info'),
    # good
    path('points_table/', views.points_table, name='points_table'),
    path('select_teams/', views.select_teams, name='select_teams'),
    path('condition/', views.condition, name='condition'),
    # --4
    path('search/batsman/', views.search_batsman, name='search_batsman'),
    path('search_bowlerr/', views.search_bowler, name='search_bowler'),
    path('searhcricket/', views.searhcricket, name='searhcricket'),

    path('add_player/', views.add_player, name='add_player'),
    path('view_players/', views.view_players, name='view_players'),
    path('update_player/<int:player_id>/', views.update_player, name='update_player'),
    path('remove_player/<int:player_id>/', views.remove_player, name='remove_player'),
    path('fixtures/', views.fixtures, name='fixtures'),
    path('players/download/csv/', views.download_csv, name='download_csv'),
    # ---------------

    # media
            path('upload/image/', views.upload_image, name='upload_image'),
    path('upload/video/', views.upload_video, name='upload_video'),
    path('upload/file/', views.upload_file, name='upload_file'),

    path('images/', views.view_images, name='view_images'),
    path('videos/', views.view_videos, name='view_videos'),
    path('files/', views.view_files, name='view_files'),
    path('Media/', views.Media, name='Media'),
    # -8
    path('videos/delete/<int:video_id>/', views.delete_video, name='delete_video'),
    path('images/delete/<int:image_id>/', views.delete_image, name='delete_image'),
    path('files/delete/<int:file_id>/', views.delete_file, name='delete_file'),
    #----------------------------------------------------------

    #path('reset-password/<int:user_id>/', views.reset_password, name='reset_password'),
    path('owners/', views.owners, name='owners'),

]
